# get ip for variable income, if income is >7000 loan available, else not eligible

income = int(input())
if(income>7000):
    print("Eligible for loan")
else:
    print(" Not Eligible for loan")


