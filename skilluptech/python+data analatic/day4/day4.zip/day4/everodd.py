num= int(input())
if(num%2==0):
    print("Its an even")
else:
    print("Odd")

#HW
# get ip for socre out of 100, if socre <35="yet to improve",score>35<70"avg std", score>70="keep going"
