x=int(input("X: "))
y=int(input("Y: "))
opration=input("add/sub/mul/div: ")
if(opration == "add"):
    print(x+y)
elif(opration == "sub"):
     print(x-y)
elif(opration == "mul"):
     print(x*y)
elif(opration == "div"):
     print(x/y)
else:
     print("Invalid operation")

#HW-2 
# get a ip for socre per, only if % is > 70, get ip name, dept, location, print eligible for scholorship