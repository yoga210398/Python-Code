#for i in range(1,5):
   # print("*",end="|")

for i in range(1,5):#rowss
    print()
    for j in range(1,i+1):#cls  1, 0+1=1
        print(j,end="")

