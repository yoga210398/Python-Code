#for i in range(1,6):#12345
 ##   for j in range(1,3):#12
  ##      print(j,"Apple")
for i in range(1,3):
    print("week:" ,i)
    for j in range(1,4):
        print("Day: ",j)

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    #week1
    # day1
    #day2
    #day3
    #week2
     # day1
    #day2
    #day3
    