#wrte a prg to read 10 numbers from the keyboard and find their sum and avg.

a=[]
for i in range(10):
    num =int(input("enter ur num: "+str(i)+" "))
    a.append(num)
print(a)