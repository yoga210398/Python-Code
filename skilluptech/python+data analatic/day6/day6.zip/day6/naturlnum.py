#write a aprogram to compute the sum of the first 5 natural numbers
sum =0 #0+1,,  1+2  3+3
for i in range(1,6):
    sum = sum+i
print(sum)

