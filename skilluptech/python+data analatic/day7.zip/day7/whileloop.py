# for ... initailization, condition, increment
# i=0;
# while(i=0);
#print(i)
#i++
i=10 #ture
while(i>0):
    print(i,end=",")
    i=i-1

