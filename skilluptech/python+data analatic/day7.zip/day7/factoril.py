num = int(input("enter ur number: "))
fact=1
i=1
while i<=num:
    fact=fact*i# 1*3=3
    i=i+1
print(f"the factorial of our number is: {fact}")
    #1*2=2
    #1*1=1... 3*2*1=6