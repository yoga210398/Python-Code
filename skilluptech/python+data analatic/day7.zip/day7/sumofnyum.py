i=1
sum=0
while(i<=10):
    sum+=i
    i+=1
print(f"the sum of number from 1-10 is: {sum}")